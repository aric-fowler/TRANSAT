# Format:
# from file import method
# 'method' is a function present in a file called 'file.py'

from .satAttack import satAttack